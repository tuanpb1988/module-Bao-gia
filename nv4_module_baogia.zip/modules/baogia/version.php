<?php

/**
 * @Project NUKEVIET 4.x
 * @Author Phạm Bá Tuấn <tuanpb1988@gmail.com>
 * @Copyright (C) 2021 Phạm Bá Tuấn. All rights reserved
 * @License: Not free read more http://nukeviet.vn/vi/store/modules/nvtools/
 * @Createdate Fri, 01 Oct 2021 08:01:10 GMT
 */

if (!defined('NV_MAINFILE'))
    die('Stop!!!');

$module_version = array(
    'name' => 'Baogia',
    'modfuncs' => 'bao-gia,search,main',
    'change_alias' => 'bao-gia,search,main',
    'submenu' => 'bao-gia,main',
    'is_sysmod' => 0,
    'virtual' => 0,
    'version' => '4.3.03',
    'date' => 'Fri, 1 Oct 2021 08:01:10 GMT',
    'author' => 'Phạm Bá Tuấn (tuanpb1988@gmail.com)',
    'uploads_dir' => array($module_name),
    'note' => 'Module báo giá linh kiện máy tính'
);
