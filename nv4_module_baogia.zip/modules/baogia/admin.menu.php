<?php

/**
 * @Project NUKEVIET 4.x
 * @Author Phạm Bá Tuấn <tuanpb1988@gmail.com>
 * @Copyright (C) 2021 Phạm Bá Tuấn. All rights reserved
 * @License: Not free read more http://nukeviet.vn/vi/store/modules/nvtools/
 * @Createdate Fri, 01 Oct 2021 08:01:10 GMT
 */

if (!defined('NV_ADMIN'))
    die('Stop!!!');

$submenu['pro'] = $lang_module['pro'];
$submenu['cat'] = $lang_module['cat'];
