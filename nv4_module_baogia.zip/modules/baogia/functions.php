<?php

/**
 * @Project NUKEVIET 4.x
 * @Author Phạm Bá Tuấn <tuanpb1988@gmail.com>
 * @Copyright (C) 2021 Phạm Bá Tuấn. All rights reserved
 * @License: Not free read more http://nukeviet.vn/vi/store/modules/nvtools/
 * @Createdate Fri, 01 Oct 2021 08:01:10 GMT
 */

if (!defined('NV_SYSTEM'))
    die('Stop!!!');

define('NV_IS_MOD_BAOGIA', true);

$array_cat_id_baogia = [];

// Cache Categories
$_sql = 'SELECT cat_id,cat_name FROM nv4_vi_baogia_cat where status=1 ORDER BY weight ASC';
$_query = $nv_Cache->db($_sql, 'cat_id', $module_name);

foreach ($_query as $_row) {
    $array_cat_id_baogia[$_row['cat_id']] = $_row['cat_name'];
}

//cache Products
$_sql = 'SELECT * FROM nv4_vi_baogia_pro WHERE status = 1 ORDER BY cat_id ASC, id DESC';
$_query = $nv_Cache->db($_sql, 'id', $module_name);

foreach ($_query as $_row) {
    $_row['cat_name'] = $array_cat_id_baogia[$_row['cat_id']];
    $_row['price_display'] = number_format($_row['price'], 0, ',', '.');
    $array_products[$_row['id']] = $_row;
}
