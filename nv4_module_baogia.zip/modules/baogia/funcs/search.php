<?php

/**
 * @Project NUKEVIET 4.x
 * @Author VINADES.,JSC <contact@vinades.vn>
 * @Copyright (C) 2021 VINADES.,JSC. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate Sun, 03 Oct 2021 09:24:54 GMT
 */

if (!defined('NV_IS_MOD_BAOGIA'))
    die('Stop!!!');

$result = [];

if ($nv_Request->isset_request('load_data', 'post, get')) {
    $q = $nv_Request->get_title('q', 'post, get', '');
    $type = $nv_Request->get_int('type', 'post, get', 1);
    $where = '';


    $row = array();
    if (!empty($q)) {
        if ($type == 1) {
            $where = ' AND pro_name LIKE ' . $db->quote('%' . $q . '%');
            $field = 'pro_name';
        } else {
            $where = ' AND code LIKE ' . $db->quote('%' . $q . '%');
            $field = 'code';
        }
        $_sql = 'SELECT * FROM nv4_vi_baogia_pro WHERE status = 1 ' . $where . 'ORDER BY cat_id ASC, id DESC';

        // $_query = $db->query($_sql);
        // while ($row = $_query->fetch()) {
        //     $number++;
        //     $row['cat_name'] = $array_cat_id_baogia[$row['cat_id']];
        //     $result[$row['cat_id']][] = $row;
        // }
        foreach ($array_products as $id => $pro) {
            //echo stristr($pro[$field], $q) . '<br>';
            if (!empty(stristr($pro[$field], $q))) {
                $pro['price_display'] = number_format($pro['price'], 0, ',', '.');
                $pro['price_display'] .= empty($pro['price_display']) ? '' : $lang_module['currency'];
                $pro['saleprice_display'] = number_format($pro['sale_price'], 0, ',', '.');
                $pro['saleprice_display'] .= empty($pro['saleprice_display']) ? '' : $lang_module['currency'];
                $result[$pro['cat_id']][] = $pro;
            }
        }
    } else {
        foreach ($array_products as $id => $pro) {
            $pro['price_display'] = number_format($pro['price'], 0, ',', '.');
            $pro['price_display'] .= empty($pro['price_display']) ? '' : $lang_module['currency'];
            $pro['saleprice_display'] = number_format($pro['sale_price'], 0, ',', '.');
            $pro['saleprice_display'] .= empty($pro['saleprice_display']) ? '' : $lang_module['currency'];
            $result[$pro['cat_id']][] = $pro;
        }
    }
}

if (!empty($result)) {
    $contents = nv_theme_baogia_search($result);
}

include(NV_ROOTDIR . "/includes/header.php");
echo $contents;
include(NV_ROOTDIR . "/includes/footer.php");
