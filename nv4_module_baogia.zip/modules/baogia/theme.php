<?php

/**
 * @Project NUKEVIET 4.x
 * @Author Phạm Bá Tuấn <tuanpb1988@gmail.com>
 * @Copyright (C) 2021 Phạm Bá Tuấn. All rights reserved
 * @License: Not free read more http://nukeviet.vn/vi/store/modules/nvtools/
 * @Createdate Fri, 01 Oct 2021 08:01:10 GMT
 */

if (!defined('NV_IS_MOD_BAOGIA'))
    die('Stop!!!');

/**
 * nv_theme_baogia_bao_gia()
 * 
 * @param mixed $array_data
 * @return
 */
function nv_theme_baogia_bao_gia($array_data)
{
    global $module_info, $lang_module, $lang_global, $op;

    $xtpl = new XTemplate($op . '.tpl', NV_ROOTDIR . '/themes/' . $module_info['template'] . '/modules/' . $module_info['module_theme']);
    $xtpl->assign('LANG', $lang_module);
    $xtpl->assign('GLANG', $lang_global);

    //------------------
    // Viết code vào đây
    //------------------

    $xtpl->parse('main');
    return $xtpl->text('main');
}

/**
 * nv_theme_baogia_search()
 * 
 * @param mixed $array_data
 * @return
 */
function nv_theme_baogia_search($array_data)
{
    global $module_info, $lang_module, $lang_global, $op, $array_cat_id_baogia;

    $xtpl = new XTemplate($op . '.tpl', NV_ROOTDIR . '/themes/' . $module_info['template'] . '/modules/' . $module_info['module_theme']);
    $xtpl->assign('LANG', $lang_module);
    $xtpl->assign('GLANG', $lang_global);

    foreach ($array_data as $cat_id => $cat_data) {
        if (!empty($cat_data)) {
            foreach ($cat_data as $pro) {
                $xtpl->assign('PRO', $pro);
                $xtpl->parse('main.CAT.loop');
            }
            $cat_name = $array_cat_id_baogia[$cat_id];
            $xtpl->assign('CAT_NAME', $cat_name);
            $xtpl->parse('main.CAT');
        }
    }

    $xtpl->parse('main');
    return $xtpl->text('main');
}

/**
 * nv_theme_baogia_main()
 * 
 * @param mixed $array_data
 * @return
 */
function nv_theme_baogia_main($array_data)
{
    global $module_info, $lang_module, $lang_global, $op;

    $xtpl = new XTemplate($op . '.tpl', NV_ROOTDIR . '/themes/' . $module_info['template'] . '/modules/' . $module_info['module_theme']);
    $xtpl->assign('LANG', $lang_module);
    $xtpl->assign('GLANG', $lang_global);

    //------------------
    // Viết code vào đây
    //------------------

    $xtpl->parse('main');
    return $xtpl->text('main');
}
