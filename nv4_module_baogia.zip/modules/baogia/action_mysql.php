<?php

/**
 * @Project NUKEVIET 4.x
 * @Author VINADES.,JSC <contact@vinades.vn>
 * @Copyright (C) 2021 VINADES.,JSC. All rights reserved
 * @License: Not free read more http://nukeviet.vn/vi/store/modules/nvtools/
 * @Createdate Mon, 04 Oct 2021 14:08:21 GMT
 */

if (!defined('NV_IS_FILE_MODULES'))
    die('Stop!!!');

$sql_drop_module = array();
$sql_drop_module[] = "DROP TABLE IF EXISTS " . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_cat";
$sql_drop_module[] = "DROP TABLE IF EXISTS " . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_pro";

$sql_create_module = $sql_drop_module;
$sql_create_module[] = "CREATE TABLE " . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_cat(
  cat_id int(11) NOT NULL AUTO_INCREMENT,
  cat_name varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  status int(1) NOT NULL DEFAULT 1,
  weight int(11) NOT NULL DEFAULT 0,
  cat_alias varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  PRIMARY KEY (cat_id)
) ENGINE=MyISAM";

$sql_create_module[] = "CREATE TABLE " . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_pro(
  id int(11) NOT NULL AUTO_INCREMENT,
  cat_id int(11) NOT NULL DEFAULT 0,
  pro_name varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  price int(11) NOT NULL DEFAULT 0,
  sale_price int(11) NOT NULL DEFAULT 0 COMMENT 'Giá sỉ',
  code varchar(25) NOT NULL DEFAULT '',
  status tinyint(1) NOT NULL DEFAULT 1,
  guarantee varchar(50) NOT NULL DEFAULT '0' COMMENT 'Bảo hành',
  PRIMARY KEY (id)
) ENGINE=MyISAM";
