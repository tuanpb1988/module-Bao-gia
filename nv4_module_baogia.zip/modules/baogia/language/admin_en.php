<?php

/**
* @Project NUKEVIET 4.x
* @Author VINADES.,JSC <contact@vinades.vn>
* @Copyright (C) 2021 VINADES.,JSC. All rights reserved
* @Language English
* @License CC BY-SA (http://creativecommons.org/licenses/by-sa/4.0/)
* @Createdate Oct 01, 2021, 08:05:42 AM
*/

if (!defined('NV_ADMIN') or !defined('NV_MAINFILE'))
    die('Stop!!!');

$lang_translator['author'] = 'VINADES.,JSC (contact@vinades.vn)';
$lang_translator['createdate'] = '01/10/2021, 15:05';
$lang_translator['copyright'] = 'Copyright (C) 2021 VINADES.,JSC. All rights reserved';
$lang_translator['info'] = '';
$lang_translator['langtype'] = 'lang_module';



//Lang for function cat
$lang_module['cat'] = 'cat';
$lang_module['edit'] = 'edit';
$lang_module['delete'] = 'Delete';
$lang_module['number'] = 'Number';
$lang_module['active'] = 'Trạng thái';
$lang_module['search_title'] = 'Enter keywords searching';
$lang_module['search_submit'] = 'Search';
$lang_module['cat_name'] = 'Cat name';
$lang_module['error_required_cat_name'] = 'Error: Required fields enter the Cat name';
$lang_module['save'] = 'Save';

//Lang for function cat
$lang_module['status'] = 'Status';
$lang_module['cat_alias'] = 'Cat alias';

//Lang for function pro
$lang_module['pro'] = 'pro';

//Lang for function pro
$lang_module['pro_name'] = 'Pro name';
$lang_module['price'] = 'Price';
$lang_module['code'] = 'Code';
$lang_module['guarantee'] = 'Guarantee';
$lang_module['error_required_pro_name'] = 'Error: Required fields enter the Pro name';
$lang_module['error_required_price'] = 'Error: Required fields enter the Price';
$lang_module['error_required_code'] = 'Error: Required fields enter the Code';
$lang_module['error_required_guarantee'] = 'Error: Required fields enter the Guarantee';

//Lang for function pro
$lang_module['cat_id'] = 'Cat id';
$lang_module['error_required_cat_id'] = 'Error: Required fields enter the Cat id';
