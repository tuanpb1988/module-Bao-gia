<?php

/**
 * @Project NUKEVIET 4.x
 * @Author VINADES.,JSC <contact@vinades.vn>
 * @Copyright (C) 2021 VINADES.,JSC. All rights reserved
 * @License: Not free read more http://nukeviet.vn/vi/store/modules/nvtools/
 * @Createdate Mon, 04 Oct 2021 14:08:21 GMT
 */

if (!defined('NV_ADMIN'))
    die('Stop!!!');

try {
    $db->query("INSERT INTO " . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_cat (cat_id, cat_name, status, weight, cat_alias) VALUES('1', 'MAIN SOCKET 2066 X-SERIES', '1', '1', '')");
} catch (PDOException $e) {
    trigger_error($e->getMessage());
}
try {
    $db->query("INSERT INTO " . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_cat (cat_id, cat_name, status, weight, cat_alias) VALUES('3', 'MAIN SOCKET 1200 GEN 10TH', '1', '2', '')");
} catch (PDOException $e) {
    trigger_error($e->getMessage());
}
try {
    $db->query("INSERT INTO " . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_cat (cat_id, cat_name, status, weight, cat_alias) VALUES('4', 'MAIN SOCKET 2011', '1', '3', '')");
} catch (PDOException $e) {
    trigger_error($e->getMessage());
}
try {
    $db->query("INSERT INTO " . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_cat (cat_id, cat_name, status, weight, cat_alias) VALUES('5', 'MAIN SOCKET 1151 V2', '1', '4', '')");
} catch (PDOException $e) {
    trigger_error($e->getMessage());
}

try {
    $db->query("INSERT INTO " . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_pro (id, cat_id, pro_name, price, sale_price, code, status, guarantee) VALUES('1', '1', 'Mainboard Asus B560M-K/CSM Prime', '10000000', '200000', '143190', '1', '36')");
} catch (PDOException $e) {
    trigger_error($e->getMessage());
}
try {
    $db->query("INSERT INTO " . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_pro (id, cat_id, pro_name, price, sale_price, code, status, guarantee) VALUES('2', '1', 'Nhẫn đá hổ phách giọt nước', '100000', '250000', 'ABC123', '1', '20')");
} catch (PDOException $e) {
    trigger_error($e->getMessage());
}
try {
    $db->query("INSERT INTO " . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_pro (id, cat_id, pro_name, price, sale_price, code, status, guarantee) VALUES('3', '3', 'Nhẫn đá hổ phách giọt nước 2', '100000', '200000', 'ABC123', '1', '24')");
} catch (PDOException $e) {
    trigger_error($e->getMessage());
}
try {
    $db->query("INSERT INTO " . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_pro (id, cat_id, pro_name, price, sale_price, code, status, guarantee) VALUES('4', '4', 'Mainboard Asus H410M-F Prime', '120000', '200000', 'A12023', '1', '20')");
} catch (PDOException $e) {
    trigger_error($e->getMessage());
}
try {
    $db->query("INSERT INTO " . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_pro (id, cat_id, pro_name, price, sale_price, code, status, guarantee) VALUES('5', '4', 'Mainboard Asus B460M-K Prime', '300000', '300000', 'A00921', '1', '12')");
} catch (PDOException $e) {
    trigger_error($e->getMessage());
}
try {
    $db->query("INSERT INTO " . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_pro (id, cat_id, pro_name, price, sale_price, code, status, guarantee) VALUES('6', '1', 'Mainboard Asus B460M-Plus TUF Gaming Wifi (TUF GAMING B460M-PLUS (WI-FI))', '800000', '200000', 'AKFKAJD', '1', '12')");
} catch (PDOException $e) {
    trigger_error($e->getMessage());
}
try {
    $db->query("INSERT INTO " . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_pro (id, cat_id, pro_name, price, sale_price, code, status, guarantee) VALUES('7', '1', 'Mainboard Asrock H470M-HVS', '500000', '200000', 'ABC123', '1', '2')");
} catch (PDOException $e) {
    trigger_error($e->getMessage());
}
try {
    $db->query("INSERT INTO " . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_pro (id, cat_id, pro_name, price, sale_price, code, status, guarantee) VALUES('8', '3', 'Mainboard HUANANZHI X79 Dual-4D', '150000', '100000', 'AKFKAJD', '1', '2')");
} catch (PDOException $e) {
    trigger_error($e->getMessage());
}
try {
    $db->query("INSERT INTO " . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_pro (id, cat_id, pro_name, price, sale_price, code, status, guarantee) VALUES('9', '5', 'Mainboard Asus TUF B360M-Plus Gaming', '500000', '200000', 'A1202', '1', '36')");
} catch (PDOException $e) {
    trigger_error($e->getMessage());
}
try {
    $db->query("INSERT INTO " . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_pro (id, cat_id, pro_name, price, sale_price, code, status, guarantee) VALUES('10', '4', 'Mainboard Asus B460M-K Prime 2', '300', '200000', 'A202', '1', '12')");
} catch (PDOException $e) {
    trigger_error($e->getMessage());
}
try {
    $db->query("INSERT INTO " . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_pro (id, cat_id, pro_name, price, sale_price, code, status, guarantee) VALUES('13', '1', 'test', '400000', '200000', '', '1', '1 tuần')");
} catch (PDOException $e) {
    trigger_error($e->getMessage());
}
