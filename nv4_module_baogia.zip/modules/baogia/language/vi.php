<?php

/**
 * @Project NUKEVIET 4.x
 * @Author Phạm Bá Tuấn <tuanpb1988@gmail.com>
 * @Copyright (C) 2021 Phạm Bá Tuấn. All rights reserved
 * @License: Not free read more http://nukeviet.vn/vi/store/modules/nvtools/
 * @Createdate Fri, 01 Oct 2021 08:01:10 GMT
 */

if (!defined('NV_MAINFILE'))
    die('Stop!!!');

$lang_translator['author'] = 'Phạm Bá Tuấn (tuanpb1988@gmail.com)';
$lang_translator['createdate'] = '01/10/2021, 08:01';
$lang_translator['copyright'] = '@Copyright (C) 2021 VINADES.,JSC. All rights reserved';
$lang_translator['info'] = '';
$lang_translator['langtype'] = 'lang_module';

$lang_module['bao-gia'] = 'Báo Giá';
$lang_module['search'] = 'Tìm kiếm';
$lang_module['main'] = 'Trang chính';

//Lang for function main
$lang_module['add'] = 'Thêm mới';
$lang_module['edit'] = 'Sửa';
$lang_module['delete'] = 'Xóa';
$lang_module['number'] = 'STT';
$lang_module['active'] = 'Trạng thái';
$lang_module['cat_id'] = 'Cat id';
$lang_module['pro_name'] = 'Tên sản phẩm';
$lang_module['price'] = 'Đơn giá';
$lang_module['sale_price'] = 'Giá sỉ';
$lang_module['code'] = 'Mã SP';
$lang_module['status'] = 'Status';
$lang_module['guarantee'] = 'Bảo hành';

//Lang for function search
$lang_module['search_title'] = 'Nhập từ khóa tìm kiếm';
$lang_module['search_submit'] = 'Tìm kiếm';
$lang_module['currency'] = 'đ';
