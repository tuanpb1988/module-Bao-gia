<?php

/**
* @Project NUKEVIET 4.x
* @Author VINADES.,JSC <contact@vinades.vn>
* @Copyright (C) 2021 VINADES.,JSC. All rights reserved
* @Language English
* @License CC BY-SA (http://creativecommons.org/licenses/by-sa/4.0/)
* @Createdate Oct 02, 2021, 07:03:09 AM
*/

if (!defined('NV_MAINFILE'))
    die('Stop!!!');

$lang_translator['author'] = 'VINADES.,JSC (contact@vinades.vn)';
$lang_translator['createdate'] = '02/10/2021, 14:03';
$lang_translator['copyright'] = 'Copyright (C) 2021 VINADES.,JSC. All rights reserved';
$lang_translator['info'] = '';
$lang_translator['langtype'] = 'lang_module';



//Lang for function main
$lang_module['main'] = 'main';
$lang_module['edit'] = 'edit';
$lang_module['delete'] = 'Delete';
$lang_module['number'] = 'Number';
$lang_module['active'] = 'Trạng thái';
$lang_module['cat_id'] = 'Cat id';
$lang_module['pro_name'] = 'Product name';
$lang_module['price'] = 'Price';
$lang_module['code'] = 'Code';
$lang_module['status'] = 'Status';
$lang_module['guarantee'] = 'Guarantee';

//Lang for function search
$lang_module['search'] = 'search';
$lang_module['search_title'] = 'Enter keywords searching';
$lang_module['search_submit'] = 'Search';
