/**
 * @Project NUKEVIET 4.x
 * @Author Phạm Bá Tuấn <tuanpb1988@gmail.com>
 * @Copyright (C) 2021 Phạm Bá Tuấn. All rights reserved
 * @License: Not free read more http://nukeviet.vn/vi/store/modules/nvtools/
 * @Createdate Fri, 01 Oct 2021 08:01:10 GMT
 */

 function FormatNumber(str, separator=',') {
      var strTemp = GetNumber(str,separator);
      var dec;
      if (separator == ',') {
          dec = '.';
      } else {
          dec = ',';
      }
      if (strTemp.length <= 3) {
          return strTemp;
      }
      strResult = "";
      for (var i = 0; i < strTemp.length; i++) {
          strTemp = strTemp.replace(separator, "");
      }
      var m = strTemp.lastIndexOf(dec);
      if (m == -1) {
          for (var i = strTemp.length; i >= 0; i--) {
              if (strResult.length > 0 && (strTemp.length - i - 1) % 3 == 0) {
                  strResult = separator + strResult;
              }
              strResult = strTemp.substring(i, i + 1) + strResult;
          }
      } else {
          var strphannguyen = strTemp.substring(0, strTemp.lastIndexOf(dec));
          var strphanthapphan = strTemp.substring(strTemp.lastIndexOf(dec), strTemp.length);
          var tam = 0;
          for (var i = strphannguyen.length; i >= 0; i--) {

              if (strResult.length > 0 && tam == 4) {
                  strResult = separator + strResult;
                  tam = 1;
              }

              strResult = strphannguyen.substring(i, i + 1) + strResult;
              tam = tam + 1;
          }
          strResult = strResult + strphanthapphan;
      }
      return strResult;
 }
 function GetNumber(str,separator='.') {
     var count = 0;
     var dec;
     if (separator == ',') {
         dec = '.';
     } else {
         dec = ',';
     }
     for (var i = 0; i < str.length; i++) {
         var temp = str.substring(i, i + 1);
         if (!(temp == "," || temp == "." || (temp >= 0 && temp <= 9))) {
             //alert(inputnumber);
             return str.substring(0, i);
         }
         if (temp == " ") {
             return str.substring(0, i);
         }
         if (temp == dec) {
             if (count > 0) {
                 return str.substring(0, i);
             }
             count++;
         }
     }
     return str;
 }
